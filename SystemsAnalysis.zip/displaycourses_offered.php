<html>
<body>


Results of classlists Database<br><br>

<?php
   // Display Data in the database
   
   // connect to the server
   $dbcnx = @mysql_connect("localhost", "quickme1_4211",
   "csci4211");


if (!$dbcnx) { 
    echo( "<p>Unable to connect to the " . 
          "database server at this time.</p>" 
   ); 
    exit(); 
  }

 
// Select the personal database 
  if (! @mysql_select_db("quickme1_4211") ) { 
    echo( "<p>Unable to locate registration database " . 
          "database at this time.</p>" ); 
    exit(); 
  } 
  
  
   // retrieve all the rows from the database
   $query = "SELECT * FROM `classlists` ORDER BY `courseID`;
   
   $results = mysql_query( $query );

   // print out the results
   if( $results )
   {
      while( $classlists = mysql_fetch_object( $results ) )
      {
         // print out the info
         $courseID = $classlists -> courseID;
         $sectionID = $classlists -> sectionID;
         $facultyID = $classlists -> facultyID;
         $studentID = $classlists -> studentID;
         $LocationID = $classlists -> LocationID;
         $Time = $classlists -> Time;
         $CRN_Number = $classlists -> CRN_Number;
         echo( "$courseID<br>, $sectionID<br>, $facultyID<br>, $studentID<br>, $LocationID<br>, $Time<br>, $CRN_Number<br><br><br>" );
      }
   }
   else
   {
      echo( "Trouble getting contacts from database: ");
   }
   
?>

</body>
</html>
